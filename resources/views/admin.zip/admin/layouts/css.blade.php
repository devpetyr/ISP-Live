<!-- Bootstrap CSS -->
<link href="{{asset('admin/css/animate.css')}}" rel="stylesheet" />
<link href="{{asset('admin/fontawesome5/css/all.min.css')}}" rel="stylesheet" />
<link href="{{asset('admin/slick/slick-theme.css')}}" rel="stylesheet" type="text/css" />
<link href="{{asset('admin/slick/slick.css')}}" rel="stylesheet" type="text/css" />
<link href="{{asset('admin/css/slicknav.css')}}" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="{{asset('admin/css/jquery.fancybox.min.css')}}" />
<link href="{{asset('admin/css/bootstrap.min.css')}}" rel="stylesheet" />
<link href="{{asset('admin/css/custom.css')}}" rel="stylesheet" />

<!--datatable css cdn-->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/jszip-2.5.0/dt-1.10.16/b-1.5.1/b-html5-1.5.1/datatables.min.css"/>

@stack('css')
