<div class="col-md-12 col-sm-12 col-xs-12">
    <div class="dash_bg">
        <div class="dash_1">
            <a href="javascript:void(0)">International Student Placements</a>
        </div>
        <div class="dash_2">
            <nav id="top-nav">
                <ul class="">
                    <li>
                        <a href="{{route('admin_dashboard')}}">Dashboard
                        </a>
                    </li>

                    <li class="dropdown">
                        <a href="#">Students
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="#">Student Profile </a></li>
                            <li><a href="{{route('admin_student_applications')}}">Student Applications </a></li>
                            <li><a href="#">Payments</a></li>
                            <li><a href="#">Schools</a></li>
                            <li><a href="#">Regions</a></li>
                        </ul>
                    </li>

                    <li class="dropdown">
                        <a href="#">Hosts
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="#">Host Profile </a></li>
                            <li><a href="#">Host Visits</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="#">Airport Pickup
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="#">Airport Pickup</a></li>
                            <li><a href="#">Drivers</a></li>
                            <li><a href="#">Airlines</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="#">Agents
                        </a>
                    </li>

                    <li>
                        <a href="#">Coordinators
                        </a>
                    </li>
                    <li class="dropdown">
                        <a href="#">Reports
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="#">Placement</a></li>
                            <li><a href="#">Placement Status</a></li>
                            <li><a href="#"> Airport Driver Assignments</a></li>
                            <li><a href="#"> Host Background Check Status</a></li>
                            <li><a href="#"> Host Availability</a></li>
                            <li><a href="#"> Host Visit Status</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="#"><i class="fa-solid fa-user"></i>Admin
                        </a>
                        <ul class="dropdown-menu">
                    <li><a href="javascript:void(0)">My Profile</a></li>
                    <li>
{{--                        <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#exampleModal">Change Password</a>--}}
                        <a href="javascript:void(0)" >Change Password</a>
                    </li>
                    <li>
{{--                        <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#staticBackdrop">Common Settings</a>--}}
                        <a href="javascript:void(0)" >Common Settings</a>
                    </li>
                    <li><a href="{{route('logout')}}">Sign Out</a></li>
                        </ul>
                    </li>
                </ul>
            </nav>
        </div>
        <div class="admin_div">
            <img src="{{asset('admin/images/150-26.jpg')}}" class="img-fluid" alt="" />
            <h4>{{auth()->user()->username}}</h4>
            <h5>{{auth()->user()->email}}</h5>
        </div>

    </div>
</div>
